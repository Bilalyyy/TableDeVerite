import UIKit

let elementName : [String] = ["mari",
                              "épouse",
                              "fils",
                              "fille",
                              "fils du fils",
                              "fille du fils",
                              "pere",
                              "mere",
                              "mere de la mere",
                              "pere du pere",
                              "mere du pere",
                              "frere germain",
                              "frere utérin",
                              "frere consanguin",
                              "soeurs germaine",
                              "soeurs utérine",
                              "soeurs consanguine",
                              
]



var myTruthTable : [String:[Bool]] = [:]

func howManyLines(for elements: [String] = elementName)-> Int {
    var output = 1
    for _ in 0..<elements.count {
        output *= 2
    }
    return output
}

print(howManyLines())


func howManyLines(for number: Int)-> Int {
    var output = 1
    for _ in 0..<number {
        output *= 2
    }
    return output
}


func makeMytruthTable(nbrLine: Int = howManyLines(), with elements: [String] = elementName)-> [String: [Bool]] {
    var output : [String:[Bool]] = [:]
    var limitForToggle = 1
    elements.forEach { element in
        var index = 1
        var state = Bool()
        
        for _ in 0..<nbrLine {
            index == 1 ? output[element] = [state] : output[element]?.append(state)
            if index % limitForToggle == 0 {
                state.toggle()
            }
            index += 1
        }
        limitForToggle *= 2
    }
    return output
}



print(makeMytruthTable())

//print(howManyLines(for: 17))
